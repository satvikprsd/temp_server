from weaviate.collections.collection.async_ import CollectionAsync
from weaviate.collections.collection.sync import Collection

__all__ = ["CollectionAsync", "Collection"]
